import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { exec } from "child_process";
import { promisify } from "util";

dotenv.config();

const execPromise = promisify(exec);

async function startServer() {
  const app = express();
  const PORT = 3000;

  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || "",
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  app.use(express.json());

  // API Route for Gemini Agent
  app.post("/api/agent/chat", async (req, res) => {
    const key = process.env.GEMINI_API_KEY || "";
    if (!key || key === "MY_GEMINI_API_KEY" || key.trim() === "") {
      return res.status(400).json({
        error: "GEMINI_API_KEY is not configured",
        message: "Lumina AI Agent requires a valid Gemini API Key to function. Please set your actual GEMINI_API_KEY in the environment or a .env file."
      });
    }

    try {
      const { message, history, systemInstruction } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [...(history || []), { role: "user", parts: [{ text: message }] }],
        config: {
          systemInstruction: systemInstruction || "You are Lumina, a personal AI OS assistant. You help manage the user's virtual environment.",
        },
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // API Route for System Status details (checking API Key configuration status)
  app.get("/api/system/status", (req, res) => {
    const key = process.env.GEMINI_API_KEY || "";
    const isConfigured = !!key && key !== "MY_GEMINI_API_KEY" && key.trim() !== "";
    res.json({
      status: "online",
      apiKeyConfigured: isConfigured,
      platform: process.platform,
      nodeVersion: process.version,
    });
  });

  // API Route for Shell Command execution (restricted to sandbox)
  app.post("/api/system/exec", async (req, res) => {
    try {
      const { command } = req.body;
      // Basic security: don't allow potentially destructive commands if we were truly public, 
      // but in this container it's limited to the user's workspace.
      if (!command) return res.status(400).json({ error: "No command provided" });
      
      const { stdout, stderr } = await execPromise(command);
      res.json({ stdout, stderr });
    } catch (error: any) {
      res.status(500).json({ error: error.message, stderr: error.stderr });
    }
  });

  // API Route for File Management (Read/List)
  app.get("/api/system/files", async (req, res) => {
    try {
      // Improved file listing to get paths relative to root, excluding common noise
      const { stdout } = await execPromise("find . -maxdepth 2 -not -path '*/.*' -not -path './node_modules*' -not -path './dist*' -not -path '.'");
      res.json({ files: stdout });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // User Preferences
  let userPrefs = {
    theme: 'Classic',
    name: 'User',
    voiceSensitivity: 50,
    hotkeys: {
      terminal: 't',
      explorer: 'e',
      settings: 's',
      notes: 'n',
    }
  };

  // Notes Storage
  let notes: { id: string, title: string, content: string }[] = [
    { id: '1', title: 'Welcome Note', content: 'Welcome to Lumina OS. Start by exploring your files!' }
  ];

  app.get("/api/system/prefs", (req, res) => {
    res.json(userPrefs);
  });

  app.post("/api/system/prefs", (req, res) => {
    userPrefs = { ...userPrefs, ...req.body };
    res.json(userPrefs);
  });

  app.get("/api/system/notes", (req, res) => {
    res.json(notes);
  });

  app.post("/api/system/notes", (req, res) => {
    const { id, title, content } = req.body;
    const existing = notes.find(n => n.id === id);
    if (existing) {
      existing.title = title;
      existing.content = content;
    } else {
      notes.push({ id: id || Date.now().toString(), title, content });
    }
    res.json({ success: true });
  });

  app.delete("/api/system/notes/:id", (req, res) => {
    notes = notes.filter(n => n.id !== req.params.id);
    res.json({ success: true });
  });

  // API Route for reading file content
  app.get("/api/system/file/content", async (req, res) => {
    try {
      const filePath = req.query.path as string;
      if (!filePath) return res.status(400).json({ error: "No path provided" });
      
      // Basic security: stay within current directory
      const absolutePath = path.resolve(process.cwd(), filePath);
      if (!absolutePath.startsWith(process.cwd())) {
        return res.status(403).json({ error: "Access denied" });
      }

      const { stdout } = await execPromise(`cat "${filePath}" | head -n 100`);
      res.json({ content: stdout });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Lumina AI OS running at http://localhost:${PORT}`);
  });
}

startServer();
