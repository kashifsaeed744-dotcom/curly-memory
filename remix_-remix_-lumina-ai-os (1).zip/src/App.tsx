import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal as TerminalIcon, 
  Folder, 
  Settings as SettingsIcon, 
  Mic, 
  MicOff, 
  Search, 
  Cpu, 
  HardDrive, 
  Activity,
  X,
  Minus,
  Maximize2,
  Lock,
  User,
  Power,
  Volume2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WindowState, ChatMessage } from './types';

// Components
const Window = ({ 
  state, 
  onClose, 
  onMinimize, 
  onFocus, 
  children 
}: { 
  state: WindowState; 
  onClose: () => void; 
  onMinimize: () => void; 
  onFocus: () => void;
  children: React.ReactNode;
  key?: React.Key;
}) => {
  if (!state.isOpen || state.isMinimized) return null;

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0.9, opacity: 0 }}
      drag
      dragMomentum={false}
      onMouseDown={onFocus}
      style={{ zIndex: state.zIndex }}
      className="absolute bg-[#1a1a1a]/90 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden min-w-[400px] min-h-[300px]"
    >
      <div className="flex items-center justify-between px-4 py-2 bg-white/5 border-b border-white/5 cursor-move">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-white/60 tracking-wider uppercase">{state.title}</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onMinimize} className="p-1 hover:bg-white/10 rounded-md transition-colors text-white/60 hover:text-white">
            <Minus size={14} />
          </button>
          <button onClick={onClose} className="p-1 hover:bg-red-500/20 rounded-md transition-colors text-white/60 hover:text-red-400">
            <X size={14} />
          </button>
        </div>
      </div>
      <div className="p-4 h-full overflow-auto text-white/90">
        {children}
      </div>
    </motion.div>
  );
};

export default function App() {
  const [windows, setWindows] = useState<WindowState[]>([
    { id: 'terminal', title: 'Terminal', isOpen: false, isMinimized: false, zIndex: 10 },
    { id: 'explorer', title: 'File Explorer', isOpen: false, isMinimized: false, zIndex: 11 },
    { id: 'settings', title: 'Lumina Settings', isOpen: false, isMinimized: false, zIndex: 12 },
    { id: 'notes', title: 'Notes', isOpen: false, isMinimized: false, zIndex: 13 },
  ]);
  const [isListening, setIsListening] = useState(false);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [systemStats, setSystemStats] = useState({ cpu: 0, ram: 0, uptime: '0h 0m' });
  const [vibe, setVibe] = useState('Classic');
  const [userName, setUserName] = useState('User');
  const [hotkeys, setHotkeys] = useState({ terminal: 't', explorer: 'e', settings: 's', notes: 'n' });
  const [notifications, setNotifications] = useState<{ id: number, text: string }[]>([]);
  const [showStartMenu, setShowStartMenu] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const [apiKeyConfigured, setApiKeyConfigured] = useState<boolean | null>(null);
  const [systemNodeVersion, setSystemNodeVersion] = useState<string>('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const speak = (text: string) => {
    if (!ttsEnabled || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.1;
    utterance.pitch = 1.1;
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    // Load preferences
    fetch('/api/system/prefs')
      .then(res => res.json())
      .then(data => {
        if (data.theme) setVibe(data.theme);
        if (data.name) setUserName(data.name);
        if (data.hotkeys) setHotkeys(data.hotkeys);
      });

    // Load system status (diagnostics)
    fetch('/api/system/status')
      .then(res => res.json())
      .then(data => {
        setApiKeyConfigured(data.apiKeyConfigured);
        setSystemNodeVersion(data.nodeVersion);
      })
      .catch(err => console.error(err));

    // Global Hotkey Listener
    const handleKeyDown = (e: KeyboardEvent) => {
      // Only trigger if Alt key is held to avoid clashing with typing
      if (!e.altKey) return;

      const key = e.key.toLowerCase();
      if (key === hotkeys.terminal) {
        e.preventDefault();
        toggleWindow('terminal');
        addNotification(`Hotkey: Opening Terminal`);
      } else if (key === hotkeys.explorer) {
        e.preventDefault();
        toggleWindow('explorer');
        addNotification(`Hotkey: Opening Explorer`);
      } else if (key === hotkeys.settings) {
        e.preventDefault();
        toggleWindow('settings');
        addNotification(`Hotkey: Opening Settings`);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [hotkeys, windows]); // Re-bind when hotkeys change or windows state logic needs it (though toggleWindow uses setter)

  useEffect(() => {
    // Simulated system spikes
    const interval = setInterval(() => {
      setSystemStats({
        cpu: Math.floor(Math.random() * 15) + 2,
        ram: 34 + Math.floor(Math.random() * 5),
        uptime: '2d 14h'
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const toggleWindow = (id: string) => {
    setWindows(prev => prev.map(w => 
      w.id === id ? { ...w, isOpen: !w.isOpen, isMinimized: false, zIndex: Math.max(...prev.map(w => w.zIndex)) + 1 } : w
    ));
  };

  const focusWindow = (id: string) => {
    setWindows(prev => {
      const maxZ = Math.max(...prev.map(w => w.zIndex));
      return prev.map(w => w.id === id ? { ...w, zIndex: maxZ + 1 } : w);
    });
  };

  const addNotification = (text: string) => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, text }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 3000);
  };

  const savePrefs = async (updates: any) => {
    try {
      await fetch('/api/system/prefs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      addNotification('Preferences updated');
    } catch (err) {
      console.error(err);
    }
  };

  const handleCommand = async (text: string) => {
    if (!text.trim()) return;

    const newUserMsg: ChatMessage = { role: 'user', parts: [{ text }] };
    setChatHistory(prev => [...prev, newUserMsg]);
    setInputText('');
    setIsProcessing(true);

    try {
      const res = await fetch('/api/agent/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: text, 
          history: chatHistory,
          systemInstruction: `You are Lumina, a personal AI OS assistant. 
          Current environment: Sandbox PC. User name: ${userName}.
          You can help the user with file management, terminal commands, and system settings.
          If the user wants to see files, tell them to open the File Explorer.
          If the user wants to use terminal, tell them to open the Terminal.
          Respond in a helpful, concise way. Current Vibe: ${vibe}.`
        })
      });
      const data = await res.json();
      
      if (!res.ok) {
        const errMsg = data.message || data.error || "Lumina was unable to process your request.";
        const modelMsg: ChatMessage = { role: 'model', parts: [{ text: `Configuration Alert: ${errMsg}` }] };
        setChatHistory(prev => [...prev, modelMsg]);
        speak("System configuration error. Please check your API key settings.");
        addNotification("Lumina Error: Key required");
        return;
      }
      
      const modelMsg: ChatMessage = { role: 'model', parts: [{ text: data.text }] };
      setChatHistory(prev => [...prev, modelMsg]);
      speak(data.text);

      // Simple action detection
      const responseText = data.text.toLowerCase();
      if (responseText.includes('opening file explorer') || responseText.includes('opening explorer')) {
        toggleWindow('explorer');
        addNotification('System: Opening File Explorer');
      }
      if (responseText.includes('opening terminal') || responseText.includes('opening shell')) {
        toggleWindow('terminal');
        addNotification('System: Opening Terminal');
      }
      if (responseText.includes('opening settings')) {
        toggleWindow('settings');
        addNotification('System: Opening Settings');
      }
      if (responseText.includes('opening notes')) {
        toggleWindow('notes');
        addNotification('System: Opening Notes');
      }

    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const startVoice = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const text = event.results[0][0].transcript;
      handleCommand(text);
    };
    recognition.start();
  };

  return (
    <div className={`h-screen w-screen overflow-hidden bg-black font-sans selection:bg-white/20`}>
      {/* Dynamic Wallpaper Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0c0c0e] via-[#1a1a2e] to-[#0c0c0e] opacity-90" />
        <div className="absolute inset-0 overflow-hidden opacity-30">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-500 rounded-full blur-[120px] animate-pulse" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-purple-500 rounded-full blur-[120px] animate-pulse" />
        </div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 pointer-events-none" />
      </div>

      {/* Notifications */}
      <div className="absolute top-8 right-8 z-[100] flex flex-col gap-2 pointer-events-none">
        <AnimatePresence>
          {notifications.map(n => (
            <motion.div
              key={n.id}
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 100, opacity: 0 }}
              className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg px-4 py-2 text-white text-xs shadow-xl pointer-events-auto"
            >
              {n.text}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Start Menu */}
      <AnimatePresence>
        {showStartMenu && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            className="absolute bottom-20 left-4 w-64 bg-[#0a0a0a]/90 backdrop-blur-2xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-[60]"
          >
            <div className="p-4 border-b border-white/5 bg-white/5 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                {userName.charAt(0)}
              </div>
              <div>
                <div className="text-xs font-bold text-white tracking-wider">{userName}</div>
                <div className="text-[10px] text-white/40">Power User</div>
              </div>
            </div>
            <div className="p-2 space-y-1">
              <StartMenuItem icon={TerminalIcon} label="Terminal" onClick={() => { toggleWindow('terminal'); setShowStartMenu(false); }} />
              <StartMenuItem icon={Folder} label="Explorer" onClick={() => { toggleWindow('explorer'); setShowStartMenu(false); }} />
              <StartMenuItem icon={SettingsIcon} label="Settings" onClick={() => { toggleWindow('settings'); setShowStartMenu(false); }} />
              <div className="h-[1px] bg-white/5 my-1 mx-2" />
              <StartMenuItem icon={Power} label="Sleep" onClick={() => addNotification('Entering low power mode...')} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop Content */}
      <main className="relative z-10 h-full p-8 flex flex-col items-center justify-center">
        
        {/* Lumina Core Orb */}
        <motion.div 
          animate={{ 
            scale: isProcessing ? [1, 1.1, 1] : 1,
            rotate: isProcessing ? 360 : 0
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="relative group cursor-pointer"
          onClick={() => setIsProcessing(!isProcessing)}
        >
          <div className="absolute inset-0 bg-white/20 rounded-full blur-2xl group-hover:bg-white/30 transition-all duration-500" />
          <div className="relative w-48 h-48 rounded-full border border-white/20 flex items-center justify-center bg-black/40 backdrop-blur-md">
            <div className={`w-32 h-32 rounded-full bg-gradient-to-tr from-blue-500 to-purple-600 blur-xl opacity-60 animate-pulse`} />
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 border border-black">
              <span className="text-2xl font-bold tracking-[0.2em] text-white">LUMINA</span>
              <span className="text-[10px] uppercase tracking-tighter text-white/40">AI Agent active</span>
            </div>
          </div>
        </motion.div>

        {/* Floating Chat Interface */}
        <div className="mt-12 w-full max-w-2xl flex flex-col gap-4">
          <div className="h-[200px] overflow-y-auto px-4 space-y-4 scrollbar-hide">
            {chatHistory.map((msg, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                  msg.role === 'user' 
                  ? 'bg-blue-600/20 text-blue-100 border border-blue-500/30' 
                  : 'bg-white/5 text-white/90 border border-white/10'
                }`}>
                  {msg.parts[0].text}
                </div>
              </motion.div>
            ))}
            <div ref={chatEndRef} />
          </div>

          <div className="relative flex items-center gap-2 bg-white/5 backdrop-blur-lg border border-white/10 rounded-full p-2 pl-6 focus-within:border-white/30 transition-all">
            <input 
              type="text" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCommand(inputText)}
              placeholder="Ask Lumina anything..."
              className="flex-1 bg-transparent border-none outline-none text-white placeholder:text-white/30 text-sm"
            />
            <button 
              onClick={startVoice}
              className={`p-3 rounded-full transition-all ${isListening ? 'bg-red-500/20 text-red-400' : 'hover:bg-white/10 text-white/60'}`}
            >
              {isListening ? <Mic size={20} /> : <MicOff size={20} />}
            </button>
          </div>
        </div>

        {/* Windows Layer */}
        <AnimatePresence>
          {windows.map(w => (
            <Window 
              key={w.id} 
              state={w}
              onFocus={() => focusWindow(w.id)}
              onClose={() => toggleWindow(w.id)}
              onMinimize={() => toggleWindow(w.id)}
            >
              {w.id === 'terminal' && <TerminalComponent />}
              {w.id === 'explorer' && <ExplorerComponent />}
              {w.id === 'notes' && <NotesComponent />}
              {w.id === 'settings' && (
                <div className="space-y-6">
                  <div className="flex flex-col gap-4">
                    <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                      <div className="text-xs text-white/40 uppercase tracking-tighter mb-2">User Profile</div>
                      <div className="flex items-center gap-3">
                        <User size={16} className="text-white/60" />
                        <input 
                          type="text" 
                          value={userName}
                          onChange={(e) => {
                            setUserName(e.target.value);
                            savePrefs({ name: e.target.value });
                          }}
                          className="bg-transparent border-none outline-none text-white font-medium flex-1"
                          placeholder="Your Name"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10">
                      <div>
                        <h4 className="font-medium text-white">Voice Synthesis</h4>
                        <p className="text-[10px] text-white/40">Lumina speaks responses</p>
                      </div>
                      <button 
                        onClick={() => setTtsEnabled(!ttsEnabled)}
                        className={`p-2 rounded-lg transition-colors ${ttsEnabled ? 'bg-blue-600 text-white' : 'bg-white/5 text-white/40'}`}
                      >
                        {ttsEnabled ? <Volume2 size={14} /> : <Volume2 className="opacity-40" size={14} />}
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10">
                      <div>
                        <h4 className="font-medium text-white">Visual Vibe</h4>
                        <p className="text-[10px] text-white/40">OS Personalization</p>
                      </div>
                      <select 
                        value={vibe}
                        onChange={(e) => {
                          setVibe(e.target.value);
                          savePrefs({ theme: e.target.value });
                        }}
                        className="bg-black border border-white/20 text-white rounded px-2 py-1 text-[10px] outline-none"
                      >
                        <option>Classic</option>
                        <option>Cyberpunk</option>
                        <option>Minimal</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10">
                      <div>
                        <h4 className="font-medium text-white">Voice Sensitivity</h4>
                        <p className="text-[10px] text-white/40">AI trigger threshold</p>
                      </div>
                      <input type="range" className="accent-blue-500 w-24 h-1" />
                    </div>

                    <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                      <div className="text-xs text-white/40 uppercase tracking-tighter mb-2">System Diagnostics</div>
                      <div className="space-y-2 text-xs">
                        <div className="flex justify-between items-center">
                          <span className="text-white/60">Node.js version:</span>
                          <span className="font-mono text-blue-400">{systemNodeVersion || "Detecting..."}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-white/60">Gemini connection:</span>
                          {apiKeyConfigured === null ? (
                            <span className="text-white/40 font-mono">Checking...</span>
                          ) : apiKeyConfigured ? (
                            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium bg-green-500/10 text-green-400 border border-green-500/20">
                              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                              Active / Configured
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium bg-red-400/10 text-red-400 border border-red-500/20">
                              <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                              Key Required
                            </span>
                          )}
                        </div>
                        {!apiKeyConfigured && apiKeyConfigured !== null && (
                          <div className="mt-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-[10px] text-red-200/90 leading-relaxed font-sans">
                            Lumina requires a valid <code className="bg-black/40 px-1 py-0.5 rounded text-red-400 font-mono">GEMINI_API_KEY</code>. Please set it in your environment or a local <code className="bg-black/40 px-1 py-0.5 rounded text-red-400 font-mono">.env</code> file.
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                      <div className="text-xs text-white/40 uppercase tracking-tighter mb-3">Alt + Hotkeys</div>
                      <div className="grid grid-cols-3 gap-2">
                        {Object.entries(hotkeys).map(([app, key]) => (
                          <div key={app} className="flex flex-col gap-1">
                            <span className="text-[10px] text-white/40 capitalize">{app}</span>
                            <input 
                              type="text" 
                              maxLength={1}
                              value={key}
                              onChange={(e) => {
                                const newKey = e.target.value.toLowerCase();
                                if (newKey) {
                                  const newHotkeys = { ...hotkeys, [app]: newKey };
                                  setHotkeys(newHotkeys);
                                  savePrefs({ hotkeys: newHotkeys });
                                }
                              }}
                              className="bg-black border border-white/10 rounded px-2 py-1 text-center text-xs text-blue-400 font-mono focus:border-blue-500 outline-none"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => {
                      confetti();
                      addNotification('Diagnostics complete. System healthy.');
                    }}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-blue-600/20"
                  >
                    RUN SYSTEM OPTIMIZATION
                  </button>
                </div>
              )}
            </Window>
          ))}
        </AnimatePresence>
      </main>

      {/* Taskbar */}
      <nav className="absolute bottom-0 w-full h-16 px-4 flex items-center justify-between bg-[#0a0a0a]/80 backdrop-blur-3xl border-t border-white/5 z-50">
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowStartMenu(!showStartMenu)}
            className={`p-2 rounded-xl transition-all ${showStartMenu ? 'bg-white/20 scale-95 shadow-inner' : 'bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/20 hover:scale-105'}`}
          >
            <Activity className="text-white" size={20} />
          </button>
          <div className="h-8 w-[1px] bg-white/10 mx-2" />
          <div className="flex items-center gap-1">
            <AppIcon icon={TerminalIcon} active={windows.find(w => w.id === 'terminal')?.isOpen} onClick={() => toggleWindow('terminal')} />
            <AppIcon icon={Folder} active={windows.find(w => w.id === 'explorer')?.isOpen} onClick={() => toggleWindow('explorer')} />
            <AppIcon icon={Search} active={windows.find(w => w.id === 'notes')?.isOpen} onClick={() => toggleWindow('notes')} />
            <AppIcon icon={SettingsIcon} active={windows.find(w => w.id === 'settings')?.isOpen} onClick={() => toggleWindow('settings')} />
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-4 text-white/40">
            <div className="flex items-center gap-2">
              <Cpu size={14} />
              <span className="text-xs font-mono">{systemStats.cpu}%</span>
            </div>
            <div className="flex items-center gap-2">
              <HardDrive size={14} />
              <span className="text-xs font-mono">{systemStats.ram} GB</span>
            </div>
          </div>
          <div className="h-8 w-[1px] bg-white/10" />
          <div className="flex flex-col items-end">
            <span className="text-xs font-bold text-white/90">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            <span className="text-[10px] uppercase text-white/40 tracking-tighter">{new Date().toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
          </div>
        </div>
      </nav>
    </div>
  );
}

const StartMenuItem = ({ icon: Icon, label, onClick }: { icon: any, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className="w-full flex items-center gap-3 p-2.5 rounded-xl text-white/60 hover:text-white hover:bg-white/5 transition-all text-xs font-medium"
  >
    <Icon size={16} />
    {label}
  </button>
);

const NotesComponent = () => {
  const [notes, setNotes] = useState<{ id: string, title: string, content: string }[]>([]);
  const [activeNote, setActiveNote] = useState<string | null>(null);

  const fetchNotes = () => {
    fetch('/api/system/notes')
      .then(res => res.json())
      .then(setNotes);
  };

  useEffect(fetchNotes, []);

  const saveNote = (title: string, content: string) => {
    fetch('/api/system/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: activeNote, title, content })
    }).then(fetchNotes);
  };

  const currentNote = notes.find(n => n.id === activeNote);

  return (
    <div className="flex h-full gap-4 overflow-hidden">
      <div className="w-1/3 border-r border-white/5 pr-4 space-y-2 overflow-y-auto scrollbar-hide">
        <button 
          onClick={() => { setActiveNote(null); }}
          className="w-full text-left p-2 rounded-lg bg-blue-600/20 text-blue-400 text-xs font-bold hover:bg-blue-600/30 transition-all border border-blue-500/30"
        >
          + NEW NOTE
        </button>
        {notes.map(n => (
          <div 
            key={n.id} 
            onClick={() => setActiveNote(n.id)}
            className={`p-3 rounded-xl cursor-pointer transition-all ${activeNote === n.id ? 'bg-white/10 border border-white/20' : 'hover:bg-white/5'}`}
          >
            <div className="text-xs font-bold text-white truncate">{n.title}</div>
            <div className="text-[10px] text-white/40 truncate">{n.content}</div>
          </div>
        ))}
      </div>
      <div className="flex-1 flex flex-col gap-4">
        <input 
          className="bg-transparent text-lg font-bold text-white outline-none" 
          placeholder="Note Title..."
          value={currentNote?.title || ''}
          onChange={(e) => saveNote(e.target.value, currentNote?.content || '')}
        />
        <textarea 
          className="flex-1 bg-transparent text-sm text-white/70 outline-none resize-none font-mono"
          placeholder="Start writing..."
          value={currentNote?.content || ''}
          onChange={(e) => saveNote(currentNote?.title || 'Untitled', e.target.value)}
        />
      </div>
    </div>
  );
};

const AppIcon = ({ icon: Icon, active, onClick }: { icon: any, active?: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`p-2.5 rounded-xl transition-all relative ${active ? 'bg-white/10 text-white' : 'text-white/40 hover:bg-white/5 hover:text-white/60'}`}
  >
    <Icon size={20} />
    {active && <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-blue-500 rounded-full" />}
  </button>
);

const TerminalComponent = () => {
  const [history, setHistory] = useState<string[]>(['Lumina OS [v1.0.4] Welcome user.', 'Type "help" for system commands.']);
  const [input, setInput] = useState('');

  const exec = async (cmd: string) => {
    setHistory(prev => [...prev, `> ${cmd}`]);
    setInput('');
    
    try {
      const res = await fetch('/api/system/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd })
      });
      const data = await res.json();
      if (data.stdout) setHistory(prev => [...prev, data.stdout]);
      if (data.stderr) setHistory(prev => [...prev, `Error: ${data.stderr}`]);
    } catch (err: any) {
      setHistory(prev => [...prev, `Critical System Error: ${err.message}`]);
    }
  };

  return (
    <div className="font-mono text-sm h-full flex flex-col">
      <div className="flex-1 overflow-auto space-y-1">
        {history.map((line, i) => (
          <div key={i} className="whitespace-pre-wrap">{line}</div>
        ))}
      </div>
      <div className="flex items-center gap-2 mt-4 text-blue-400">
        <span>$</span>
        <input 
          autoFocus
          className="bg-transparent border-none outline-none flex-1 text-white" 
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && exec(input)}
        />
      </div>
    </div>
  );
};

const ExplorerComponent = () => {
  const [files, setFiles] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);

  const refresh = () => {
    setLoading(true);
    fetch('/api/system/files')
      .then(res => res.json())
      .then(data => {
        const fileList = data.files.split('\n')
          .filter((f: string) => f.trim())
          .map((f: string) => f.replace('./', ''));
        setFiles(fileList);
        setLoading(false);
      });
  };

  useEffect(() => {
    refresh();
  }, []);

  const fetchContent = async (path: string) => {
    setSelectedFile(path);
    setIsPreviewLoading(true);
    setFileContent(null);
    try {
      const res = await fetch(`/api/system/file/content?path=${encodeURIComponent(path)}`);
      const data = await res.json();
      setFileContent(data.content || 'No content or binary file.');
    } catch (err) {
      setFileContent('Error loading preview.');
    } finally {
      setIsPreviewLoading(false);
    }
  };

  const filteredFiles = files.filter(file => 
    file.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const isImage = (path: string) => /\.(jpg|jpeg|png|gif|svg|webp)$/i.test(path);

  return (
    <div className="flex h-full gap-4 overflow-hidden">
      {/* File List */}
      <div className={`flex flex-col h-full gap-4 transition-all duration-300 ${selectedFile ? 'w-1/2' : 'w-full'}`}>
        <div className="relative flex items-center bg-white/5 border border-white/10 rounded-lg px-3 py-2 gap-2 focus-within:border-blue-500/50 transition-colors">
          <Search size={14} className="text-white/40" />
          <input 
            type="text" 
            placeholder="Search files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent border-none outline-none text-sm text-white placeholder:text-white/20 w-full"
          />
          <div className="flex items-center gap-2">
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="text-white/40 hover:text-white">
                <X size={14} />
              </button>
            )}
            <button onClick={refresh} className="text-white/40 hover:text-white transition-colors">
              <Activity size={14} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 overflow-y-auto scrollbar-hide pb-20">
          {loading ? (
            <div className="col-span-full text-center py-8 text-white/20">Indexing filesystem...</div>
          ) : filteredFiles.length > 0 ? (
            filteredFiles.map((file, i) => (
              <div 
                key={i} 
                onClick={() => fetchContent(file)}
                className={`flex flex-col items-center gap-2 p-3 rounded-xl cursor-pointer transition-all group ${selectedFile === file ? 'bg-white/10 border border-white/20 shadow-lg' : 'hover:bg-white/5 border border-transparent'}`}
              >
                <div className="relative">
                  <Folder className={`${selectedFile === file ? 'text-blue-400' : 'text-blue-500'} group-hover:scale-110 transition-transform`} size={32} fill="currentColor" fillOpacity={0.1} />
                  <div className={`absolute inset-0 bg-blue-400/20 blur-xl transition-opacity ${selectedFile === file ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`} />
                </div>
                <span className="text-[10px] text-white/70 text-center truncate w-full">{file}</span>
              </div>
            ))
          ) : (
            <div className="col-span-full text-center py-8 text-white/20">No files found matching "{searchQuery}"</div>
          )}
        </div>
      </div>

      {/* Preview Pane */}
      <AnimatePresence>
        {selectedFile && (
          <motion.div 
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 20, opacity: 0 }}
            className="w-1/2 flex flex-col bg-white/5 border border-white/10 rounded-xl overflow-hidden"
          >
            <div className="p-3 bg-white/5 border-b border-white/5 flex items-center justify-between">
              <span className="text-[10px] font-mono text-white/40 truncate flex-1 mr-2">{selectedFile}</span>
              <button onClick={() => setSelectedFile(null)} className="text-white/40 hover:text-white">
                <X size={14} />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4 font-mono text-xs text-white/60 whitespace-pre">
              {isPreviewLoading ? (
                <div className="h-full flex items-center justify-center animate-pulse">Reading file...</div>
              ) : (
                fileContent
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
